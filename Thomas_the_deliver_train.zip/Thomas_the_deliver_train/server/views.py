from django.shortcuts import render,HttpResponse,HttpResponseRedirect
# Create your views here.
def index(request):
    return render(request,"basic.html")

def save_gps(request):
    if request.method != "POST":
        return index(request)

    gps_info = request.POST

    latitude = gps_info.get("latitude","")
    longitude = gps_info.get("longitude","")
    gps_string=  str(latitude)+","+str(longitude)
    print(gps_string)
    with open("gps.txt",'w') as f:
        f.write(gps_string)
        f.close()
    return index(request)