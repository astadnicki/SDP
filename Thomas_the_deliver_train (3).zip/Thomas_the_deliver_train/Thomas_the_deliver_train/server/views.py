from django.shortcuts import render,HttpResponse,HttpResponseRedirect
import os

import paramiko
import random

#host = "172.20.10.4"
#username = "ubuntu"
#password = "raspberrypi"

host = "192.168.225.139"
username = "sdp8"
password = "intelnuc"

client = paramiko.client.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(host, username=username, password=password)

list=[0,1,2,3,4,5,6,7,8,9]
#num=str(random.choice(list)) + str(random.choice(list)) + str(random.choice(list)) + str(random.choice(list))

# Create your views here.
def index(request):
    return render(request,"basic.html")

def save_gps(request):
    if request.method != "POST":
        return index(request)

    gps_info = request.POST.get("gps_info")
    numbers=gps_info.split(" ")

    # File created on local desktop
    f=open("C:/Users/Andrew/Downloads/Thomas_the_deliver_train/Thomas_the_deliver_train/server/coordinates.yaml","w")
    f.write("waypoints:\n- latitude: "+numbers[0]+"\n  longitude: "+numbers[1]+"\n  yaw: "+numbers[2])
    f.close()

    ftp = client.open_sftp()
    ftp.put("C:/Users/Andrew/Downloads/Thomas_the_deliver_train/Thomas_the_deliver_train/server/coordinates.yaml","/home/sdp8/Desktop/coordinates.yaml")
    ftp.close()

    path = os.path.join('upload',"gps.txt")
    print(path)
    with open("gps.txt",'w') as f:
        f.write(gps_info)
        f.close()

    return index(request)