from django.shortcuts import render,HttpResponse,HttpResponseRedirect
import os
# Create your views here.
def index(request):
    return render(request,"basic.html")

def save_gps(request):
    if request.method != "POST":
        return index(request)

    gps_info = request.POST.get("gps_info")
    path = os.path.join('upload',"gps.txt")
    print(path)
    with open("gps.txt",'w') as f:
        f.write(gps_info)
        f.close()

    return index(request)